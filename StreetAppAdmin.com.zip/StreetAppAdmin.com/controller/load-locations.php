<?php 

    include '../model/db_connection/db_connection.php';
    include '../model/factories/BuildLocations.php';

    $build = new BuildLocations($conn);

    $savedLocations = $build->build();

?>