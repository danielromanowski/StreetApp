<?php

    session_start();

    $_SESSION['locationID'] = $_GET['data'];

    echo $_SESSION['locationID'];